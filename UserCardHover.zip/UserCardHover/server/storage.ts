import { users, quotes, jobs, staff, type User, type InsertUser, type Quote, type InsertQuote, type Job, type InsertJob, type Staff, type InsertStaff } from "@shared/schema";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createQuote(quote: InsertQuote): Promise<Quote>;
  getQuote(id: number): Promise<Quote | undefined>;
  getAllQuotes(): Promise<Quote[]>;
  updateQuote(id: number, updates: Partial<Quote>): Promise<Quote | undefined>;
  
  createJob(job: InsertJob): Promise<Job>;
  getJob(id: number): Promise<Job | undefined>;
  getAllJobs(): Promise<Job[]>;
  updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined>;
  getJobsByDate(date: string): Promise<Job[]>;
  
  getAllStaff(): Promise<Staff[]>;
  getStaff(id: number): Promise<Staff | undefined>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  updateStaff(id: number, updates: Partial<Staff>): Promise<Staff | undefined>;
  deleteStaff(id: number): Promise<boolean>;
  deleteAllJobs(): Promise<void>;
  deleteAllQuotes(): Promise<void>;
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const db = drizzle(pool);

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    // Create tables if they don't exist
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL
        );
      `);

      await pool.query(`
        CREATE TABLE IF NOT EXISTS quotes (
          id SERIAL PRIMARY KEY,
          customer_name TEXT NOT NULL,
          customer_email TEXT NOT NULL,
          customer_phone TEXT NOT NULL,
          package_type TEXT NOT NULL,
          service_type TEXT NOT NULL,
          vehicle_type TEXT NOT NULL,
          vehicle_subtype TEXT,
          mobile_discount BOOLEAN DEFAULT FALSE,
          extras TEXT[] DEFAULT '{}',
          base_price INTEGER NOT NULL,
          truck_fee INTEGER DEFAULT 0,
          total_price INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          admin_notes TEXT,
          dropoff_location TEXT,
          scheduled_date TIMESTAMP,
          scheduled_time TEXT,
          created_at TIMESTAMP DEFAULT NOW()
        );
      `);

      await pool.query(`
        CREATE TABLE IF NOT EXISTS jobs (
          id SERIAL PRIMARY KEY,
          quote_id INTEGER REFERENCES quotes(id),
          customer_name TEXT NOT NULL,
          package_type TEXT NOT NULL,
          service_type TEXT NOT NULL,
          total_price INTEGER NOT NULL,
          scheduled_date TIMESTAMP NOT NULL,
          status TEXT NOT NULL DEFAULT 'scheduled',
          assigned_staff TEXT,
          created_at TIMESTAMP DEFAULT NOW()
        );
      `);

      await pool.query(`
        CREATE TABLE IF NOT EXISTS staff (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          email TEXT,
          hourly_rate INTEGER DEFAULT 1500,
          hours_worked INTEGER DEFAULT 0,
          total_earnings INTEGER DEFAULT 0,
          last_payroll_date TIMESTAMP,
          is_active BOOLEAN DEFAULT TRUE
        );
      `);

      // Add missing columns to existing tables if they don't exist
      try {
        await pool.query(`
          ALTER TABLE quotes ADD COLUMN IF NOT EXISTS scheduled_date TIMESTAMP;
        `);
        await pool.query(`
          ALTER TABLE quotes ADD COLUMN IF NOT EXISTS scheduled_time TEXT;
        `);
        await pool.query(`
          ALTER TABLE staff ADD COLUMN IF NOT EXISTS notes TEXT;
        `);
        await pool.query(`
          ALTER TABLE staff ADD COLUMN IF NOT EXISTS email TEXT;
        `);
      } catch (error) {
        console.log('Columns may already exist:', error);
      }

    } catch (error) {
      console.error('Database initialization error:', error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const result = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error getting user by username:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const result = await pool.query(
        'INSERT INTO users (username, password) VALUES ($1, $2) RETURNING *',
        [insertUser.username, insertUser.password]
      );
      return result.rows[0];
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async createQuote(insertQuote: InsertQuote): Promise<Quote> {
    try {
      const result = await pool.query(`
        INSERT INTO quotes (
          customer_name, customer_email, customer_phone, package_type, 
          service_type, vehicle_type, vehicle_subtype, mobile_discount,
          extras, base_price, truck_fee, total_price, scheduled_date, scheduled_time
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) 
        RETURNING *
      `, [
        insertQuote.customerName,
        insertQuote.customerEmail,
        insertQuote.customerPhone,
        insertQuote.packageType,
        insertQuote.serviceType,
        insertQuote.vehicleType,
        insertQuote.vehicleSubtype || null,
        insertQuote.mobileDiscount || false,
        insertQuote.extras || [],
        insertQuote.basePrice,
        insertQuote.truckFee || 0,
        insertQuote.totalPrice,
        insertQuote.scheduledDate ? new Date(insertQuote.scheduledDate) : null,
        insertQuote.scheduledTime || null
      ]);
      return result.rows[0];
    } catch (error) {
      console.error('Error creating quote:', error);
      throw error;
    }
  }

  async getQuote(id: number): Promise<Quote | undefined> {
    try {
      const result = await pool.query('SELECT * FROM quotes WHERE id = $1', [id]);
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error getting quote:', error);
      return undefined;
    }
  }

  async getAllQuotes(): Promise<Quote[]> {
    try {
      const result = await pool.query('SELECT * FROM quotes ORDER BY created_at DESC');
      return result.rows;
    } catch (error) {
      console.error('Error getting all quotes:', error);
      return [];
    }
  }

  async updateQuote(id: number, updates: Partial<Quote>): Promise<Quote | undefined> {
    try {
      // Map camelCase to snake_case for database columns
      const columnMapping: Record<string, string> = {
        'adminNotes': 'admin_notes',
        'customerName': 'customer_name',
        'customerEmail': 'customer_email',
        'customerPhone': 'customer_phone',
        'packageType': 'package_type',
        'serviceType': 'service_type',
        'vehicleType': 'vehicle_type',
        'vehicleSubtype': 'vehicle_subtype',
        'mobileDiscount': 'mobile_discount',
        'basePrice': 'base_price',
        'truckFee': 'truck_fee',
        'totalPrice': 'total_price',
        'dropoffLocation': 'dropoff_location',
        'scheduledDate': 'scheduled_date',
        'scheduledTime': 'scheduled_time',
        'createdAt': 'created_at'
      };

      const setClause = Object.keys(updates)
        .filter(key => key !== 'id')
        .map((key, index) => {
          const dbColumn = columnMapping[key] || key;
          return `${dbColumn} = $${index + 2}`;
        })
        .join(', ');
      
      const values = [id, ...Object.values(updates).filter((_, index) => Object.keys(updates)[index] !== 'id')];
      
      const result = await pool.query(
        `UPDATE quotes SET ${setClause} WHERE id = $1 RETURNING *`,
        values
      );
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error updating quote:', error);
      return undefined;
    }
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    try {
      const result = await pool.query(`
        INSERT INTO jobs (quote_id, customer_name, package_type, service_type, total_price, scheduled_date, assigned_staff)
        VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *
      `, [
        insertJob.quoteId || null,
        insertJob.customerName,
        insertJob.packageType,
        insertJob.serviceType,
        insertJob.totalPrice,
        insertJob.scheduledDate,
        insertJob.assignedStaff || null
      ]);
      return result.rows[0];
    } catch (error) {
      console.error('Error creating job:', error);
      throw error;
    }
  }

  async getJob(id: number): Promise<Job | undefined> {
    try {
      const result = await pool.query('SELECT * FROM jobs WHERE id = $1', [id]);
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error getting job:', error);
      return undefined;
    }
  }

  async getAllJobs(): Promise<Job[]> {
    try {
      const result = await pool.query('SELECT * FROM jobs ORDER BY scheduled_date DESC');
      return result.rows;
    } catch (error) {
      console.error('Error getting all jobs:', error);
      return [];
    }
  }

  async updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined> {
    try {
      const setClause = Object.keys(updates)
        .filter(key => key !== 'id')
        .map((key, index) => `${key} = $${index + 2}`)
        .join(', ');
      
      const values = [id, ...Object.values(updates).filter((_, index) => Object.keys(updates)[index] !== 'id')];
      
      const result = await pool.query(
        `UPDATE jobs SET ${setClause} WHERE id = $1 RETURNING *`,
        values
      );
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error updating job:', error);
      return undefined;
    }
  }

  async getJobsByDate(date: string): Promise<Job[]> {
    try {
      const result = await pool.query(
        'SELECT * FROM jobs WHERE DATE(scheduled_date) = DATE($1)',
        [date]
      );
      return result.rows;
    } catch (error) {
      console.error('Error getting jobs by date:', error);
      return [];
    }
  }

  async getAllStaff(): Promise<Staff[]> {
    try {
      const result = await pool.query('SELECT * FROM staff ORDER BY name');
      return result.rows;
    } catch (error) {
      console.error('Error getting all staff:', error);
      return [];
    }
  }

  async getStaff(id: number): Promise<Staff | undefined> {
    try {
      const result = await pool.query('SELECT * FROM staff WHERE id = $1', [id]);
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error getting staff:', error);
      return undefined;
    }
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    try {
      const result = await pool.query(
        'INSERT INTO staff (name, email, hourly_rate, hours_worked, total_earnings, notes, is_active) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
        [
          insertStaff.name,
          insertStaff.email || null,
          insertStaff.hourlyRate || 1500, 
          insertStaff.hoursWorked || 0, 
          insertStaff.totalEarnings || 0,
          insertStaff.notes || null,
          insertStaff.isActive !== false
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error('Error creating staff:', error);
      throw error;
    }
  }

  async updateStaff(id: number, updates: Partial<Staff>): Promise<Staff | undefined> {
    try {
      // Map camelCase to snake_case for database columns
      const columnMapping: Record<string, string> = {
        'hourlyRate': 'hourly_rate',
        'hoursWorked': 'hours_worked',
        'totalEarnings': 'total_earnings',
        'lastPayrollDate': 'last_payroll_date',
        'isActive': 'is_active'
      };

      const setClause = Object.keys(updates)
        .filter(key => key !== 'id')
        .map((key, index) => {
          const dbColumn = columnMapping[key] || key;
          return `${dbColumn} = $${index + 2}`;
        })
        .join(', ');
      
      const values = [id, ...Object.values(updates).filter((_, index) => Object.keys(updates)[index] !== 'id')];
      
      const result = await pool.query(
        `UPDATE staff SET ${setClause} WHERE id = $1 RETURNING *`,
        values
      );
      return result.rows[0] || undefined;
    } catch (error) {
      console.error('Error updating staff:', error);
      return undefined;
    }
  }

  async deleteStaff(id: number): Promise<boolean> {
    try {
      const result = await pool.query('DELETE FROM staff WHERE id = $1', [id]);
      return result.rowCount > 0;
    } catch (error) {
      console.error('Error deleting staff:', error);
      return false;
    }
  }

  async deleteAllJobs(): Promise<void> {
    try {
      await pool.query('DELETE FROM jobs');
    } catch (error) {
      console.error('Error deleting all jobs:', error);
      throw error;
    }
  }

  async deleteAllQuotes(): Promise<void> {
    try {
      await pool.query('DELETE FROM quotes');
    } catch (error) {
      console.error('Error deleting all quotes:', error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();
