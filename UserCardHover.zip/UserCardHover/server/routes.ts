import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteSchema, insertJobSchema, insertStaffSchema } from "@shared/schema";
import { sendQuoteStatusEmail, sendStaffAssignmentEmail } from "./email";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Admin login
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      // Hardcoded admin credentials
      if (email === "carsonlivezey2011@icloud.com" && password === "Korakora2011!") {
        res.json({ success: true, user: { email, name: "Carson" } });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Create quote
  app.post("/api/quotes", async (req, res) => {
    try {
      const validatedData = insertQuoteSchema.parse(req.body);
      const quote = await storage.createQuote(validatedData);
      res.json(quote);
    } catch (error) {
      res.status(400).json({ message: "Invalid quote data" });
    }
  });

  // Get all quotes
  app.get("/api/quotes", async (req, res) => {
    try {
      const quotes = await storage.getAllQuotes();
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quotes" });
    }
  });

  // Create job
  app.post("/api/jobs", async (req, res) => {
    try {
      const validatedData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(validatedData);
      res.json(job);
    } catch (error) {
      res.status(400).json({ message: "Invalid job data" });
    }
  });

  // Get all jobs
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  // Get jobs by date
  app.get("/api/jobs/date/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const jobs = await storage.getJobsByDate(date);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs for date" });
    }
  });

  // Update job
  app.patch("/api/jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const job = await storage.updateJob(id, updates);

      if (!job) {
        res.status(404).json({ message: "Job not found" });
        return;
      }

      // If assigning staff, send email notification
      if (updates.assignedStaff && updates.assignedStaff !== job.assignedStaff) {
        const staff = await storage.getAllStaff();
        const assignedStaff = staff.find(s => s.name === updates.assignedStaff);

        if (assignedStaff && assignedStaff.email) {
          // Get quote details for customer info
          const quote = job.quoteId ? await storage.getQuote(job.quoteId) : null;

          const jobDetails = `
            <strong>🚗 Service:</strong> ${job.packageType || job.package_type}<br>
            <strong>🎯 Type:</strong> ${(job.serviceType || job.service_type) === 'mobile' ? 'Mobile Service' : 'Drop-off Service'}<br>
            <strong>💰 Value:</strong> $${job.totalPrice || job.total_price}
          `;

          await sendStaffAssignmentEmail({
            to: assignedStaff.email,
            staffName: assignedStaff.name,
            customerName: job.customerName || job.customer_name,
            jobDetails: jobDetails,
            serviceType: (job.serviceType || job.service_type) as 'dropoff' | 'mobile',
            scheduledDate: new Date(job.scheduledDate || job.scheduled_date).toISOString(),
            scheduledTime: new Date(job.scheduledDate || job.scheduled_date).toLocaleTimeString('en-US', { 
              hour: 'numeric', 
              minute: '2-digit',
              hour12: true 
            }),
            customerPhone: quote?.customer_phone || quote?.customerPhone || 'Not provided',
            customerEmail: quote?.customer_email || quote?.customerEmail || 'Not provided',
            totalPrice: job.totalPrice || job.total_price
          });
        }
      }

      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  // Get all staff
  app.get("/api/staff", async (req, res) => {
    try {
      const staff = await storage.getAllStaff();
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch staff" });
    }
  });

  // Create staff
  app.post("/api/staff", async (req, res) => {
    try {
      const validatedData = insertStaffSchema.parse(req.body);
      const staff = await storage.createStaff(validatedData);
      res.json(staff);
    } catch (error) {
      res.status(400).json({ message: "Invalid staff data" });
    }
  });

  // Update staff
  app.patch("/api/staff/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const staff = await storage.updateStaff(id, updates);

      if (!staff) {
        res.status(404).json({ message: "Staff member not found" });
        return;
      }

      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to update staff" });
    }
  });

  // Approve quote
  app.post("/api/quotes/:id/approve", async (req, res) => {
    try {
      const quoteId = parseInt(req.params.id);
      const { scheduledDate } = req.body;

      // Update quote status
      const quote = await storage.updateQuote(quoteId, { status: 'approved' });
      if (!quote) {
        res.status(404).json({ message: "Quote not found" });
        return;
      }

      // Create a job for the approved quote
      const job = await storage.createJob({
        quoteId: quote.id,
        customerName: quote.customer_name || quote.customerName,
        packageType: quote.package_type || quote.packageType,
        serviceType: quote.service_type || quote.serviceType,
        totalPrice: quote.total_price || quote.totalPrice,
        scheduledDate: new Date(scheduledDate),
        status: 'scheduled'
      });

      // Generate appointment ID
      const appointmentId = Math.random().toString(36).substring(2, 8).toUpperCase() + Math.floor(Math.random() * 100);

      // Send approval email with detailed breakdown
      const vehicleInfo = `${quote.vehicle_subtype || quote.vehicleSubtype} (${quote.vehicle_type || quote.vehicleType})`;
      const packageInfo = `${quote.package_type || quote.packageType} Package`;
      const serviceInfo = (quote.service_type || quote.serviceType) === 'mobile' ? 'Mobile Service' : 'Drop-off Service';
      const basePrice = quote.base_price || quote.basePrice;
      const truckFee = (quote.vehicle_type || quote.vehicleType) === 'truck' ? (quote.truck_fee || quote.truckFee || 5) : 0;
      const totalPrice = quote.total_price || quote.totalPrice;

      const detailedQuoteInfo = `
        <strong>🚗 Vehicle:</strong> ${vehicleInfo}<br>
        <strong>📦 Package:</strong> ${packageInfo} (${serviceInfo})<br>
        <strong>💰 Base Price:</strong> $${basePrice}<br>
        ${truckFee > 0 ? `<strong>🚛 Truck Fee:</strong> +$${truckFee}<br>` : ''}
        ${quote.extras && quote.extras.length > 0 ? `<strong>✨ Extras:</strong> ${quote.extras.join(', ')}<br>` : ''}
        <strong>💳 Total Amount:</strong> $${totalPrice}
      `;

      const emailSent = await sendQuoteStatusEmail({
        to: quote.customer_email || quote.customerEmail,
        customerName: quote.customer_name || quote.customerName,
        quoteDetails: detailedQuoteInfo,
        status: 'approved',
        serviceType: (quote.service_type || quote.serviceType) as 'dropoff' | 'mobile',
        scheduledDate: quote.scheduled_date ? new Date(quote.scheduled_date).toISOString() : scheduledDate,
        scheduledTime: quote.scheduled_time || new Date(scheduledDate).toLocaleTimeString('en-US', { 
          hour: 'numeric', 
          minute: '2-digit',
          hour12: true 
        }),
        dropoffLocation: 'Foam Kings by UrbanShine - 123 Main St, Your City',
        appointmentId: appointmentId
      });

      if (!emailSent) {
        console.error('Failed to send email notification');
      }

      res.json({ quote, job });
    } catch (error) {
      console.error('Error approving quote:', error);
      res.status(500).json({ message: "Failed to approve quote" });
    }
  });

  // Deny quote
  app.post("/api/quotes/:id/deny", async (req, res) => {
    try {
      const quoteId = parseInt(req.params.id);
      const { reason } = req.body;

      const quote = await storage.updateQuote(quoteId, { 
        status: 'declined',
        adminNotes: reason
      });

      if (!quote) {
        res.status(404).json({ message: "Quote not found" });
        return;
      }

      // Send denial email
      const vehicleInfo = `${quote.vehicle_subtype || quote.vehicleSubtype} (${quote.vehicle_type || quote.vehicleType})`;
      const packageInfo = `${quote.package_type || quote.packageType} Package`;
      const serviceInfo = (quote.service_type || quote.serviceType) === 'mobile' ? 'Mobile Service' : 'Drop-off Service';
      const totalPrice = quote.total_price || quote.totalPrice;

      const declineQuoteInfo = `
        <strong>🚗 Vehicle:</strong> ${vehicleInfo}<br>
        <strong>📦 Package:</strong> ${packageInfo} (${serviceInfo})<br>
        <strong>💰 Quoted Price:</strong> $${totalPrice}
      `;

      const emailSent = await sendQuoteStatusEmail({
        to: quote.customer_email || quote.customerEmail,
        customerName: quote.customer_name || quote.customerName,
        quoteDetails: declineQuoteInfo,
        status: 'declined',
        serviceType: (quote.service_type || quote.serviceType) as 'dropoff' | 'mobile',
        declineReason: reason
      });

      if (!emailSent) {
        console.error('Failed to send email notification');
      }

      res.json(quote);
    } catch (error) {
      console.error('Error denying quote:', error);
      res.status(500).json({ message: "Failed to deny quote" });
    }
  });

  // Update quote status and send email
  app.patch("/api/quotes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const quote = await storage.updateQuote(id, updates);

      if (!quote) {
        res.status(404).json({ message: "Quote not found" });
        return;
      }

      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Failed to update quote" });
    }
  });

  // Get all quotes
  app.get("/api/quotes", async (req, res) => {
    try {
      const quotes = await storage.getAllQuotes();
      res.json(quotes);
    } catch (error) {
      console.error("Error fetching quotes:", error);
      res.status(500).json({ error: "Failed to fetch quotes" });
    }
  });

  // Get all bookings (scheduled appointments) to prevent double booking
  app.get("/api/bookings", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      const bookings = jobs.map(job => ({
        date: new Date(job.scheduledDate).toDateString(),
        time: new Date(job.scheduledDate).toLocaleTimeString('en-US', { 
          hour: 'numeric', 
          minute: '2-digit',
          hour12: true 
        })
      }));
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  // Delete staff member
  app.delete("/api/staff/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteStaff(id);
      if (deleted) {
        res.json({ message: "Staff member deleted successfully" });
      } else {
        res.status(404).json({ message: "Staff member not found" });
      }
    } catch (error) {
      console.error("Error deleting staff:", error);
      res.status(500).json({ error: "Failed to delete staff member" });
    }
  });

  // Delete all jobs (for testing purposes)
  app.delete("/api/jobs/all", async (req, res) => {
    try {
      await storage.deleteAllJobs();
      res.json({ message: "All jobs deleted successfully" });
    } catch (error) {
      console.error("Error deleting all jobs:", error);
      res.status(500).json({ error: "Failed to delete all jobs" });
    }
  });

  // Delete all quotes (for testing purposes)
  app.delete("/api/quotes/all", async (req, res) => {
    try {
      await storage.deleteAllQuotes();
      res.json({ message: "All quotes deleted successfully" });
    } catch (error) {
      console.error("Error deleting all quotes:", error);
      res.status(500).json({ error: "Failed to delete all quotes" });
    }
  });

  // Send job availability notification to all active staff
  app.post("/api/staff/notify-available-jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      const unassignedJobs = jobs.filter(job => !job.assignedStaff && job.status === 'scheduled');
      const staff = await storage.getAllStaff();
      const activeStaff = staff.filter(s => s.isActive && s.email);

      if (unassignedJobs.length === 0) {
        res.json({ message: "No unassigned jobs available" });
        return;
      }

      if (activeStaff.length === 0) {
        res.json({ message: "No active staff with email addresses" });
        return;
      }

      // Send notification to each active staff member
      for (const staffMember of activeStaff) {
        const jobList = unassignedJobs.map(job => `
          • ${job.customerName} - ${job.packageType} (${new Date(job.scheduledDate).toLocaleDateString()})
        `).join('\n');

        // You can implement the email sending logic here
        console.log(`Would notify ${staffMember.name} at ${staffMember.email} about ${unassignedJobs.length} available jobs`);
      }

      res.json({ 
        message: `Notified ${activeStaff.length} staff members about ${unassignedJobs.length} available jobs`,
        notifiedStaff: activeStaff.map(s => s.name),
        availableJobs: unassignedJobs.length
      });
    } catch (error) {
      console.error("Error notifying staff:", error);
      res.status(500).json({ error: "Failed to notify staff about available jobs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}