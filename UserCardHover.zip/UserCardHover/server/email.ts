import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'foamkingsbyurbanshine@gmail.com',
    pass: 'lavr yzsf kdow bdxs'
  }
});

interface EmailData {
  to: string;
  customerName: string;
  quoteDetails: string;
  status: 'approved' | 'declined';
  serviceType: 'dropoff' | 'mobile';
  dropoffLocation?: string;
  declineReason?: string;
  scheduledDate?: string;
  scheduledTime?: string;
  appointmentId?: string;
}

interface StaffAssignmentEmailData {
  to: string;
  staffName: string;
  customerName: string;
  jobDetails: string;
  serviceType: 'dropoff' | 'mobile';
  scheduledDate: string;
  scheduledTime: string;
  customerPhone: string;
  customerEmail: string;
  totalPrice: number;
}

// Generate random appointment ID
function generateAppointmentId(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

export async function sendStaffAssignmentEmail(data: StaffAssignmentEmailData): Promise<boolean> {
  try {
    const subject = `🚗 New Job Assignment - ${data.customerName}`;

    const htmlMessage = `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 0; border-radius: 15px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">

        <!-- Header -->
        <div style="background: rgba(255,255,255,0.95); padding: 40px 30px; text-align: center; border-bottom: 3px solid #4CAF50;">
          <h1 style="color: #2E7D32; margin: 0; font-size: 28px; font-weight: bold;">🚗 New Job Assignment</h1>
          <p style="color: #666; margin: 10px 0 0 0; font-size: 16px;">Foam Kings by UrbanShine</p>
        </div>

        <!-- Main Content -->
        <div style="background: white; padding: 40px 30px;">
          <h2 style="color: #2E7D32; margin: 0 0 20px 0; font-size: 24px;">Hey ${data.staffName}! 👋</h2>

          <div style="background: linear-gradient(135deg, #4CAF50, #45a049); color: white; padding: 25px; border-radius: 10px; margin-bottom: 30px; text-align: center;">
            <h3 style="margin: 0 0 10px 0; font-size: 20px;">🎯 You've been assigned a new job!</h3>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">Get ready to make this vehicle shine!</p>
          </div>

          <!-- Customer Info -->
          <div style="background: #e3f2fd; padding: 25px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #2196F3;">
            <h4 style="color: #1976D2; margin: 0 0 15px 0; font-size: 18px;">👤 Customer Information</h4>
            <p style="margin: 5px 0; color: #333; font-size: 16px;"><strong>Name:</strong> ${data.customerName}</p>
            <p style="margin: 5px 0; color: #333; font-size: 16px;"><strong>Phone:</strong> ${data.customerPhone}</p>
            <p style="margin: 5px 0; color: #333; font-size: 16px;"><strong>Email:</strong> ${data.customerEmail}</p>
          </div>

          <!-- Job Details -->
          <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #4CAF50;">
            <h4 style="color: #2E7D32; margin: 0 0 15px 0; font-size: 18px;">📋 Job Details</h4>
            <div style="color: #333; font-size: 16px; line-height: 1.6;">
              ${data.jobDetails}
            </div>
          </div>

          <!-- Schedule -->
          <div style="background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 25px; border-radius: 10px; margin-bottom: 25px; text-align: center;">
            <h4 style="margin: 0 0 15px 0; font-size: 18px;">📅 Scheduled Time</h4>
            <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; display: inline-block;">
              <p style="margin: 0; font-size: 20px; font-weight: bold;">
                ${new Date(data.scheduledDate).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              <p style="margin: 5px 0 0 0; font-size: 18px;">🕐 ${data.scheduledTime}</p>
            </div>
          </div>

          <!-- Service Type -->
          <div style="background: #fff3e0; padding: 20px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #FF9800;">
            <h4 style="color: #F57C00; margin: 0 0 10px 0; font-size: 18px;">🎯 Service Type</h4>
            ${data.serviceType === 'mobile' ? 
              `<p style="margin: 0; color: #333; font-size: 16px;">🚗 <strong>Mobile Service</strong> - Go to customer location</p>
               <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Bring all necessary equipment and supplies.</p>` :
              `<p style="margin: 0; color: #333; font-size: 16px;">🏪 <strong>Drop-off Service</strong> - Customer brings vehicle to us</p>
               <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Vehicle will be at our location for service.</p>`
            }
          </div>

          <!-- Payment Info -->
          <div style="background: #e8f5e8; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 5px solid #4CAF50;">
            <h4 style="color: #2E7D32; margin: 0 0 10px 0; font-size: 18px;">💰 Job Value</h4>
            <p style="margin: 0; color: #333; font-size: 18px; font-weight: bold;">$${data.totalPrice}</p>
          </div>

        </div>

        <!-- Footer -->
        <div style="background: #263238; color: white; padding: 30px; text-align: center;">
          <h4 style="margin: 0 0 15px 0; font-size: 18px;">Foam Kings by UrbanShine Team</h4>
          <p style="margin: 5px 0; opacity: 0.9;">📧 foamkingsbyurbanshine@gmail.com</p>
          <p style="margin: 5px 0; opacity: 0.9;">Let's make this vehicle shine! 🌟</p>
        </div>
      </div>
    `;

    const textMessage = `Hey ${data.staffName},

You've been assigned a new job!

CUSTOMER INFO:
Name: ${data.customerName}
Phone: ${data.customerPhone}
Email: ${data.customerEmail}

JOB DETAILS:
${data.jobDetails.replace(/<br>/g, '\n').replace(/<[^>]*>/g, '')}

SCHEDULED FOR:
${new Date(data.scheduledDate).toLocaleDateString('en-US', { 
  weekday: 'long', 
  year: 'numeric', 
  month: 'long', 
  day: 'numeric' 
})} at ${data.scheduledTime}

SERVICE TYPE: ${data.serviceType === 'mobile' ? 'Mobile Service - Go to customer location' : 'Drop-off Service - Customer brings vehicle to us'}

JOB VALUE: $${data.totalPrice}

Let's make this vehicle shine!

Best regards,
Carson & The Foam Kings by UrbanShine Team
📧 foamkingsbyurbanshine@gmail.com`;

    await transporter.sendMail({
      from: 'Foam Kings by UrbanShine <foamkingsbyurbanshine@gmail.com>',
      to: data.to,
      subject: subject,
      text: textMessage,
      html: htmlMessage,
      messageId: `<staff-${Date.now()}@foamkingsbyurbanshine.com>`
    });

    return true;
  } catch (error) {
    console.error('Staff assignment email sending failed:', error);
    return false;
  }
}

export async function sendQuoteStatusEmail(data: EmailData): Promise<boolean> {
  try {
    const appointmentId = generateAppointmentId();
    const subject = data.status === 'approved' 
      ? `🎉 Your Quote Has Been APPROVED! - Elite Auto Detailing`
      : `Quote Status Update - Elite Auto Detailing`;

    // Create rich HTML email content
    const htmlMessage = data.status === 'approved' ? `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 0; border-radius: 15px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">

        <!-- Header -->
        <div style="background: rgba(255,255,255,0.95); padding: 40px 30px; text-align: center; border-bottom: 3px solid #4CAF50;">
          <h1 style="color: #2E7D32; margin: 0; font-size: 28px; font-weight: bold;">🎉 QUOTE APPROVED! 🎉</h1>
          <p style="color: #666; margin: 10px 0 0 0; font-size: 16px;">Foam Kings by UrbanShine</p>
        </div>

        <!-- Main Content -->
        <div style="background: white; padding: 40px 30px;">
          <h2 style="color: #2E7D32; margin: 0 0 20px 0; font-size: 24px;">Hey ${data.customerName}! 👋</h2>

          <div style="background: linear-gradient(135deg, #4CAF50, #45a049); color: white; padding: 25px; border-radius: 10px; margin-bottom: 30px; text-align: center;">
            <h3 style="margin: 0 0 10px 0; font-size: 20px;">🚗 Your service is ready to be scheduled! ✨</h3>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">We're excited to make your vehicle shine!</p>
          </div>

          <!-- Appointment ID -->
          <div style="background: #bbdefb; padding: 20px; border-radius: 10px; margin-bottom: 25px; text-align: center;">
              <h4 style="color: #1565c0; margin: 0 0 10px 0; font-size: 18px;">Appointment ID</h4>
              <p style="margin: 0; color: #333; font-size: 20px; font-weight: bold;">${appointmentId}</p>
              <p style="margin: 5px 0 0 0; color: #757575; font-size: 14px;">Please use this ID when making payment.</p>
          </div>

          <!-- Service Details -->
          <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #4CAF50;">
            <h4 style="color: #2E7D32; margin: 0 0 15px 0; font-size: 18px;">📋 Your Approved Service</h4>
            <div style="color: #333; font-size: 16px; line-height: 1.6;">
              ${data.quoteDetails}
            </div>
          </div>

          ${data.scheduledDate && data.scheduledTime ? `
          <!-- Scheduled Time -->
          <div style="background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 25px; border-radius: 10px; margin-bottom: 25px; text-align: center;">
            <h4 style="margin: 0 0 15px 0; font-size: 18px;">📅 Your Requested Appointment</h4>
            <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; display: inline-block;">
              <p style="margin: 0; font-size: 20px; font-weight: bold;">
                ${new Date(data.scheduledDate).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              <p style="margin: 5px 0 0 0; font-size: 18px;">🕐 ${data.scheduledTime}</p>
            </div>
          </div>
          ` : ''}

          <!-- Service Type -->
          <div style="background: #e3f2fd; padding: 20px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #2196F3;">
            <h4 style="color: #1976D2; margin: 0 0 10px 0; font-size: 18px;">🎯 Service Type</h4>
            ${data.serviceType === 'mobile' ? 
              `<p style="margin: 0; color: #333; font-size: 16px;">🚗 <strong>Mobile Service</strong> - We'll come to you!</p>
               <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Our team will arrive at your location with all equipment needed.</p>` :
              `<p style="margin: 0; color: #333; font-size: 16px;">🏪 <strong>Drop-off Service</strong> - Bring your vehicle to us</p>
               <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">📍 Location: ${data.dropoffLocation || 'Elite Auto Detailing - 123 Main St'}</p>`
            }
          </div>

          <!-- Payment Options -->
          <div style="background: #fff3e0; padding: 25px; border-radius: 10px; margin-bottom: 30px; border-left: 5px solid #FF9800;">
            <h4 style="color: #F57C00; margin: 0 0 20px 0; font-size: 18px;">💰 Choose Your Payment Method</h4>

            <div style="margin-bottom: 20px;">
              <div style="background: white; padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #4CAF50; margin-bottom: 15px;">
                <h5 style="margin: 0 0 15px 0; color: #2E7D32; font-size: 18px; font-weight: bold;">💳 Pay with Venmo (Recommended)</h5>
                <table cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                  <tr>
                    <td style="background: #4CAF50; border-radius: 30px; padding: 0;">
                      <a href="https://venmo.com/u/Carson-Livezey" 
                         style="background: #4CAF50; 
                                color: white !important; 
                                padding: 15px 30px; 
                                text-decoration: none; 
                                border-radius: 30px; 
                                font-weight: bold; 
                                font-size: 16px;
                                display: block; 
                                border: none;
                                font-family: Arial, sans-serif;">
                        💳 Pay $${data.quoteDetails.match(/\$(\d+)/)?.[1] || '0'} on Venmo
                      </a>
                    </td>
                  </tr>
                </table>
                <p style="margin: 10px 0 0 0; color: #666; font-size: 14px;">@Carson-Livezey</p>
              </div>

              <div style="background: white; padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #2196F3;">
                <h5 style="margin: 0 0 10px 0; color: #1976D2; font-size: 18px; font-weight: bold;">💵 Pay with Cash</h5>
                <p style="margin: 0; color: #666; font-size: 16px;">Pay $${data.quoteDetails.match(/\$(\d+)/)?.[1] || '0'} in cash when service is completed</p>
                 <table cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                  <tr>
                    <td style="background: #2196F3; border-radius: 25px; padding: 0;">
                      <a href="https://forms.gle/6gAMVosaLUqmGPnb6" 
                         style="background: #2196F3; 
                                color: white !important; 
                                padding: 12px 25px; 
                                text-decoration: none; 
                                border-radius: 25px; 
                                font-weight: bold; 
                                font-size: 14px;
                                display: block; 
                                border: none;
                                font-family: Arial, sans-serif;">
                      💵 Click to Report Cash Payment
                      </a>
                    </td>
                  </tr>
                </table>
                <p style="margin: 10px 0 0 0; color: #999; font-size: 14px;">Please have exact change ready</p>
              </div>
            </div>

            <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd; text-align: center;">
              <p style="margin: 0 0 15px 0; color: #333; font-size: 16px; font-weight: bold;">
                📧 Please use appointment ID when making payment
              </p>
              <table cellpadding="0" cellspacing="0" style="margin: 0 auto;">

              </table>
            </div>
          </div>

        </div>

        <!-- Footer -->
        <div style="background: #263238; color: white; padding: 30px; text-align: center;">
          <h4 style="margin: 0 0 15px 0; font-size: 18px;">Foam Kings by UrbanShine Team</h4>
          <p style="margin: 5px 0; opacity: 0.9;">📧 foamkingsbyurbanshine@gmail.com</p>
          <p style="margin: 5px 0; opacity: 0.9;">We appreciate your business and look forward to serving you! ⭐</p>
          <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #455A64;">
            <p style="margin: 0; font-size: 12px; opacity: 0.7;">
              Professional auto detailing services • Mobile & Drop-off available
            </p>
          </div>
        </div>
      </div>
    ` : `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%); padding: 0; border-radius: 15px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">

        <!-- Header -->
        <div style="background: rgba(255,255,255,0.95); padding: 40px 30px; text-align: center; border-bottom: 3px solid #e74c3c;">
          <h1 style="color: #c0392b; margin: 0; font-size: 28px; font-weight: bold;">Quote Status Update</h1>
          <p style="color: #666; margin: 10px 0 0 0; font-size: 16px;">Foam Kings by UrbanShine</p>
        </div>

        <!-- Main Content -->
        <div style="background: white; padding: 40px 30px;">
          <h2 style="color: #c0392b; margin: 0 0 20px 0; font-size: 24px;">Hello ${data.customerName},</h2>

          <div style="background: #ffebee; color: #c0392b; padding: 25px; border-radius: 10px; margin-bottom: 30px; text-align: center; border-left: 5px solid #e74c3c;">
            <h3 style="margin: 0 0 10px 0; font-size: 20px;">We're unable to approve your quote at this time</h3>
            <p style="margin: 0; font-size: 16px;">We appreciate your interest in our services</p>
          </div>

          <!-- Service Details -->
          <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #6c757d;">
            <h4 style="color: #495057; margin: 0 0 15px 0; font-size: 18px;">📋 Requested Service</h4>
            <p style="margin: 5px 0; color: #333; font-size: 16px; line-height: 1.6;">${data.quoteDetails}</p>
          </div>

          ${data.declineReason ? `
          <!-- Decline Reason -->
          <div style="background: #fff3cd; padding: 25px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #ffc107;">
            <h4 style="color: #856404; margin: 0 0 15px 0; font-size: 18px;">📝 Reason</h4>
            <p style="margin: 0; color: #333; font-size: 16px; line-height: 1.6;">${data.declineReason}</p>
          </div>
          ` : ''}

          <div style="background: #d1ecf1; padding: 25px; border-radius: 10px; margin-bottom: 30px; border-left: 5px solid #17a2b8;">
            <h4 style="color: #0c5460; margin: 0 0 15px 0; font-size: 18px;">💬 Still Interested?</h4>
            <p style="margin: 0; color: #333; font-size: 16px; line-height: 1.6;">
              Please feel free to contact us if you have any questions or would like to discuss alternative options. 
              We're here to help find a solution that works for you!
            </p>
          </div>
        </div>

        <!-- Footer -->
        <div style="background: #263238; color: white; padding: 30px; text-align: center;">
          <h4 style="margin: 0 0 15px 0; font-size: 18px;">Foam Kings by UrbanShine Team</h4>
          <p style="margin: 5px 0; opacity: 0.9;">📧 foamkingsbyurbanshine@gmail.com</p>
          <p style="margin: 5px 0; opacity: 0.9;">Thank you for considering our services</p>
        </div>
      </div>
    `;

    // Plain text version
    let textMessage = `Hey ${data.customerName},\n\n`;

    if (data.status === 'approved') {
      textMessage += `Great news! Your quote has been APPROVED! 🚗✨\n\n`;
      textMessage += `Appointment ID: ${appointmentId}\n\n`;
      textMessage += `SERVICE DETAILS:\n${data.quoteDetails}\n\n`;

      if (data.scheduledDate && data.scheduledTime) {
        textMessage += `📅 SCHEDULED FOR:\n${new Date(data.scheduledDate).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })} at ${data.scheduledTime}\n\n`;
      }

      textMessage += `🎯 SERVICE TYPE:\n`;
      if (data.serviceType === 'mobile') {
        textMessage += `Mobile Service - We'll come to you!\n\n`;
      } else {
        textMessage += `Drop-off Service\nLocation: ${data.dropoffLocation || 'Elite Auto Detailing'}\n\n`;
      }

      textMessage += `💰 PAYMENT OPTIONS:\nVenmo: https://venmo.com/u/Carson-Livezey\nOr pay in cash when service is complete and report it here: https://forms.gle/6gAMVosaLUqmGPnb6\n\nPlease use Appointment ID when making payment.\n\n`;
    } else {
      textMessage += `Unfortunately, we had to decline your quote request.\n\nSERVICE REQUESTED:\n${data.quoteDetails}\n\n`;
      if (data.declineReason) {
        textMessage += `REASON: ${data.declineReason}\n\n`;
      }
      textMessage += `Feel free to contact us with any questions.\n\n`;
    }

    textMessage += `Best regards,\nCarson & The Elite Auto Detailing Team\n📧 foamkingsbyurbanshine@gmail.com`;

    await transporter.sendMail({
      from: 'Elite Auto Detailing <foamkingsbyurbanshine@gmail.com>',
      to: data.to,
      subject: subject,
      text: textMessage,
      html: htmlMessage,
      messageId: `<${appointmentId}@foamkingsbyurbanshine.com>` // Unique message ID for each email
    });

    // Send notification to admin
    const adminNotification = data.status === 'approved' 
      ? `Quote APPROVED for ${data.customerName}\nService: ${data.quoteDetails}\nAppointment ID: ${appointmentId}\nCustomer will choose payment method.`
      : `Quote DECLINED for ${data.customerName}\nService: ${data.quoteDetails}\nReason: ${data.declineReason || 'No reason provided'}`;

    await transporter.sendMail({
      from: 'Elite Auto Detailing <foamkingsbyurbanshine@gmail.com>',
      to: 'carsonlivezey2011@icloud.com',
      subject: `Admin Notification - Quote ${data.status.toUpperCase()}`,
      text: adminNotification,
      messageId: `<admin-${appointmentId}@foamkingsbyurbanshine.com>` // Unique message ID for admin email
    });

    return true;
  } catch (error) {
    console.error('Email sending failed:', error);
    return false;
  }
}