#!/bin/bash
echo "Clearing all jobs..."
curl -X DELETE http://localhost:5000/api/jobs/all
echo ""
echo "Clearing all quotes..."
curl -X DELETE http://localhost:5000/api/quotes/all
echo ""
echo "All data cleared successfully!"
