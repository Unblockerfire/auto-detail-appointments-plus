import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  packageType: text("package_type").notNull(),
  serviceType: text("service_type").notNull(), // 'dropoff' | 'mobile'
  vehicleType: text("vehicle_type").notNull(), // 'car' | 'truck'
  vehicleSubtype: text("vehicle_subtype"), // specific car/truck type
  mobileDiscount: boolean("mobile_discount").default(false),
  extras: text("extras").array().default([]), // array of selected extras
  basePrice: integer("base_price").notNull(),
  truckFee: integer("truck_fee").default(0),
  totalPrice: integer("total_price").notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, declined
  adminNotes: text("admin_notes"),
  dropoffLocation: text("dropoff_location"),
  scheduledDate: timestamp("scheduled_date"),
  scheduledTime: text("scheduled_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  quoteId: integer("quote_id").references(() => quotes.id),
  customerName: text("customer_name").notNull(),
  packageType: text("package_type").notNull(),
  serviceType: text("service_type").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, in-progress, completed
  assignedStaff: text("assigned_staff"),
  totalPrice: integer("total_price").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  hourlyRate: integer("hourly_rate").default(1500), // stored in cents, $15.00 default
  hoursWorked: integer("hours_worked").default(0),
  totalEarnings: integer("total_earnings").default(0), // stored in cents
  lastPayrollDate: timestamp("last_payroll_date"),
  notes: text("notes"),
  isActive: boolean("is_active").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertQuoteSchema = createInsertSchema(quotes).omit({
  id: true,
  createdAt: true,
}).extend({
  scheduledDate: z.union([z.string(), z.date()]).optional(),
  scheduledTime: z.string().optional(),
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
});

export const insertStaffSchema = createInsertSchema(staff).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertQuote = z.infer<typeof insertQuoteSchema>;
export type Quote = typeof quotes.$inferSelect;

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

export type InsertStaff = z.infer<typeof insertStaffSchema>;
export type Staff = typeof staff.$inferSelect;
