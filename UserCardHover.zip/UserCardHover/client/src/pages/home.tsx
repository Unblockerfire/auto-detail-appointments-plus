import { useState } from "react";
import { Link } from "wouter";
import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Car, 
  Sparkles, 
  Clock, 
  Award, 
  Users, 
  CheckCircle, 
  Mail, 
  Phone, 
  MapPin,
  Facebook,
  Instagram,
  Star
} from "lucide-react";
import { PACKAGES } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const { toast } = useToast();

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "Thank you for contacting us. We'll get back to you soon!",
    });
    setContactForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 text-white py-24 overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                Foam Kings
              </span>
              <br />
              <span className="text-3xl md:text-5xl text-blue-200">
                by UrbanShine
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-blue-100 leading-relaxed">
              Professional car detailing that brings the shine to you. 
              <br />Experience premium quality with unmatched convenience.
            </p>

            <Link href="/quote">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-12 py-6 text-xl font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                <Sparkles className="mr-3 w-6 h-6" />
                Get Your Quote
              </Button>
            </Link>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="text-center">
                <Clock className="w-12 h-12 mx-auto mb-4 text-blue-300" />
                <h3 className="text-lg font-semibold mb-2">Same Day Service</h3>
                <p className="text-blue-200">Quick turnaround for your busy schedule</p>
              </div>
              <div className="text-center">
                <Car className="w-12 h-12 mx-auto mb-4 text-blue-300" />
                <h3 className="text-lg font-semibold mb-2">Mobile & Drop-off</h3>
                <p className="text-blue-200">We come to you or you come to us</p>
              </div>
              <div className="text-center">
                <Award className="w-12 h-12 mx-auto mb-4 text-blue-300" />
                <h3 className="text-lg font-semibold mb-2">Professional Quality</h3>
                <p className="text-blue-200">Expert care for every vehicle</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Packages</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose from our carefully crafted detailing packages designed to meet every need and budget
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {Object.entries(PACKAGES).map(([key, packageData]) => (
              <Card 
                key={key}
                className={`relative transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 ${
                  packageData.popular ? 'border-2 border-orange-500 shadow-xl' : 'border border-gray-200'
                }`}
              >
                {packageData.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-1">
                    MOST POPULAR
                  </Badge>
                )}
                <CardHeader className="text-center pb-4">
                  <div className="text-5xl mb-4">{packageData.emoji}</div>
                  <CardTitle className="text-xl font-bold text-gray-900">
                    {packageData.name}
                  </CardTitle>
                  <p className="text-gray-600 text-sm mt-2">{packageData.description[0]}</p>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-blue-600 mb-1">
                      ${packageData.dropoff}
                    </div>
                    <div className="text-sm text-gray-500">Drop-off Service</div>
                    <div className="text-xl font-semibold text-orange-500 mt-2">
                      ${packageData.mobile}
                    </div>
                    <div className="text-sm text-gray-500">Mobile Service</div>
                  </div>

                  <ul className="space-y-3 mb-6">
                    {packageData.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link href="/quote">
                    <Button 
                      className={`w-full ${
                        packageData.popular 
                          ? 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600' 
                          : 'bg-blue-600 hover:bg-blue-700'
                      } text-white`}
                    >
                      Select Package
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">About Foam Kings</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                At Foam Kings by UrbanShine, we believe your vehicle deserves the royal treatment. 
                With years of experience in professional auto detailing, we've built our reputation 
                on delivering exceptional results that exceed expectations.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Our team of skilled professionals uses only the finest products and techniques to 
                ensure your vehicle looks its absolute best. Whether you need a quick refresh or 
                a complete transformation, we're here to make your car shine like new.
              </p>

              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                  <div className="text-gray-600">Happy Customers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">3+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">What Makes Us Different</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-blue-100 rounded-full p-3 mr-4">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Expert Team</h4>
                    <p className="text-gray-600">Our certified professionals are trained in the latest detailing techniques and use premium products for superior results.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-orange-100 rounded-full p-3 mr-4">
                    <Car className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Convenience First</h4>
                    <p className="text-gray-600">Choose between our mobile service that comes to you or drop-off at our professional facility - whatever works best for your schedule.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-green-100 rounded-full p-3 mr-4">
                    <Award className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Quality Guarantee</h4>
                    <p className="text-gray-600">We stand behind our work with a satisfaction guarantee. If you're not completely happy, we'll make it right.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-purple-100 rounded-full p-3 mr-4">
                    <Sparkles className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Premium Products</h4>
                    <p className="text-gray-600">We use only the highest quality cleaning products and equipment to protect your vehicle's finish and deliver lasting results.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Media & Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Get In Touch</h2>
              <p className="text-gray-600 mb-8">
                Have questions about our services? Ready to schedule? We'd love to hear from you!
              </p>

              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="contact-name">Name</Label>
                  <Input
                    id="contact-name"
                    value={contactForm.name}
                    onChange={(e) => setContactForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Your full name"
                    required
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="contact-email">Email</Label>
                  <Input
                    id="contact-email"
                    type="email"
                    value={contactForm.email}
                    onChange={(e) => setContactForm(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="your.email@example.com"
                    required
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="contact-phone">Phone</Label>
                  <Input
                    id="contact-phone"
                    type="tel"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="(555) 123-4567"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="contact-message">Message</Label>
                  <Textarea
                    id="contact-message"
                    value={contactForm.message}
                    onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Tell us about your vehicle and what service you're interested in..."
                    rows={4}
                    required
                    className="mt-1"
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
                >
                  <Mail className="mr-2 w-5 h-5" />
                  Send Message
                </Button>
              </form>
            </div>

            {/* Contact Info & Social */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Connect With Us</h2>

              <div className="space-y-6 mb-8">
                <div className="flex items-center">
                  <Phone className="w-6 h-6 text-blue-600 mr-4" />
                  <div>
                    <div className="font-semibold text-gray-900">Call Us</div>
                    <div className="text-gray-600">(555) 123-FOAM</div>
                  </div>
                </div>

                <div className="flex items-center">
                  <Mail className="w-6 h-6 text-blue-600 mr-4" />
                  <div>
                    <div className="font-semibold text-gray-900">Email</div>
                    <div className="text-gray-600">info@foamkingsdetail.com</div>
                  </div>
                </div>

                <div className="flex items-center">
                  <MapPin className="w-6 h-6 text-blue-600 mr-4" />
                  <div>
                    <div className="font-semibold text-gray-900">Service Area</div>
                    <div className="text-gray-600">Metro Area & Surrounding Cities</div>
                  </div>
                </div>
              </div>

              <Separator className="my-8" />

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Follow Us</h3>
                <p className="text-gray-600 mb-6">
                  Stay updated with our latest work and special offers on social media!
                </p>

                <div className="flex space-x-4">
                  <a 
                    href="https://facebook.com/foamkingsbyurbanshine" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full transition-colors"
                  >
                    <Facebook className="w-6 h-6" />
                  </a>

                  <a 
                    href="https://instagram.com/foamkingsbyurbanshine" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white p-3 rounded-full transition-colors"
                  >
                    <Instagram className="w-6 h-6" />
                  </a>

                  <a 
                    href="https://tiktok.com/@foamkingsbyurbanshine" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-black hover:bg-gray-800 text-white p-3 rounded-full transition-colors"
                  >
                    <Star className="w-6 h-6" />
                  </a>
                </div>

                <p className="text-sm text-gray-500 mt-4">
                  @foamkingsbyurbanshine on all platforms
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Foam Kings by UrbanShine</h3>
            <p className="text-gray-400 mb-4">
              Professional car detailing that brings the shine to you
            </p>
            <p className="text-gray-500 text-sm">
              © 2024 Foam Kings by UrbanShine. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}