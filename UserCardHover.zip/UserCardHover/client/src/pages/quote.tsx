import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Check, ArrowLeft, ArrowRight, Truck, Car, Sparkles, Star } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PACKAGES, CAR_BRANDS, TRUCK_BRANDS, EXTRAS, type QuoteFormData } from "@/lib/types";
import { TimeSlotPicker } from "@/components/time-slot-picker";

export default function QuotePage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<QuoteFormData>>({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    packageType: "",
    serviceType: "dropoff",
    vehicleType: "car",
    vehicleSubtype: "",
    mobileDiscount: false,
    extras: ["Little Tree Black Ice Air Freshener"], // Include by default
    basePrice: 0,
    truckFee: 0,
    totalPrice: 0,
    scheduledDate: undefined,
    scheduledTime: ""
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const createQuoteMutation = useMutation({
    mutationFn: async (quoteData: QuoteFormData) => {
      const response = await apiRequest('POST', '/api/quotes', quoteData);
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Quote Submitted",
        description: "We'll review your request and send you an email confirmation within 24 hours.",
      });
      // Redirect to homepage after 2 seconds
      setTimeout(() => {
        setLocation('/');
      }, 2000);
      setStep(8); // Success page
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit quote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateTotalPrice = () => {
    if (!formData.packageType) return 0;

    const packageData = PACKAGES[formData.packageType];
    const basePrice = packageData[formData.serviceType || 'dropoff'];
    const truckFee = formData.vehicleType === 'truck' ? 5 : 0;
    const extrasTotal = (formData.extras || [])
      .map(extraName => EXTRAS.find(e => e.name === extraName)?.price || 0)
      .reduce((sum, price) => sum + price, 0);

    return basePrice + truckFee + extrasTotal;
  };

  const handleNext = () => {
    if (step === 7) {
      // Submit quote
      const totalPrice = calculateTotalPrice();
      const packageData = PACKAGES[formData.packageType!];

      const quoteData: QuoteFormData = {
        ...formData,
        basePrice: packageData[formData.serviceType || 'dropoff'],
        truckFee: formData.vehicleType === 'truck' ? 5 : 0,
        totalPrice,
        scheduledDate: formData.scheduledDate ? new Date(formData.scheduledDate).toISOString() : undefined,
        scheduledTime: formData.scheduledTime || undefined
      } as QuoteFormData;

      createQuoteMutation.mutate(quoteData);
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const updateFormData = (updates: Partial<QuoteFormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <Card className="max-w-4xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Choose Your Package</CardTitle>
              <p className="text-muted-foreground">Select the service that best fits your needs</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {Object.entries(PACKAGES).map(([key, packageData]) => (
                  <Card 
                    key={key}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-xl ${
                      formData.packageType === key ? 'ring-2 ring-primary shadow-lg' : ''
                    } ${packageData.popular ? 'border-secondary' : ''}`}
                    onClick={() => updateFormData({ packageType: key })}
                  >
                    {packageData.popular && (
                      <Badge className="absolute top-0 right-0 bg-secondary text-white rounded-bl-lg rounded-tr-lg">
                        POPULAR
                      </Badge>
                    )}
                    <CardContent className="p-6">
                      <div className="text-center mb-4">
                        <div className="text-4xl mb-2">{packageData.emoji}</div>
                        <h3 className="text-xl font-bold">{packageData.name}</h3>
                        <p className="text-sm text-muted-foreground mt-2">{packageData.description[0]}</p>
                      </div>
                      <div className="text-center mb-4">
                        <span className="text-2xl font-bold text-primary">
                          ${packageData.dropoff}
                        </span>
                        <span className="text-sm text-muted-foreground block">Drop-off</span>
                        <span className="text-lg font-semibold text-secondary">
                          ${packageData.mobile}
                        </span>
                        <span className="text-sm text-muted-foreground block">Mobile (+$10)</span>
                      </div>
                      <ul className="space-y-2 text-sm">
                        {packageData.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <Button 
                onClick={handleNext} 
                className="w-full bg-primary hover:bg-primary/90"
                disabled={!formData.packageType}
              >
                Continue <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        );

      case 2:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Service Location</CardTitle>
              <p className="text-muted-foreground">Choose how you'd like to receive your service</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    formData.serviceType === 'dropoff' ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => updateFormData({ serviceType: 'dropoff', mobileDiscount: false })}
                >
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🏪</div>
                    <h3 className="text-xl font-bold mb-2">Drop-off Service</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Bring your vehicle to our location
                    </p>
                    <Badge variant="secondary">Standard Pricing</Badge>
                  </CardContent>
                </Card>

                <Card 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    formData.serviceType === 'mobile' ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => updateFormData({ serviceType: 'mobile', mobileDiscount: true })}
                >
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🚗</div>
                    <h3 className="text-xl font-bold mb-2">Mobile Service</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      We come to your location
                    </p>
                    <Badge className="bg-secondary text-white">+$10 Service Fee</Badge>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  disabled={!formData.serviceType}
                >
                  Continue <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 3:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Vehicle Details</CardTitle>
              <p className="text-muted-foreground">Tell us about your vehicle</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <Card 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    formData.vehicleType === 'car' ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => updateFormData({ vehicleType: 'car', vehicleSubtype: '' })}
                >
                  <CardContent className="p-6 text-center">
                    <Car className="w-12 h-12 mx-auto mb-4 text-primary" />
                    <h3 className="text-lg font-semibold">Car</h3>
                    <p className="text-sm text-muted-foreground">Sedan, SUV, Hatchback, etc.</p>
                  </CardContent>
                </Card>
                <Card 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    formData.vehicleType === 'truck' ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => updateFormData({ vehicleType: 'truck', vehicleSubtype: '' })}
                >
                  <CardContent className="p-6 text-center">
                    <Truck className="w-12 h-12 mx-auto mb-4 text-primary" />
                    <h3 className="text-lg font-semibold">Truck</h3>
                    <p className="text-sm text-muted-foreground">Pickup truck, work truck, etc.</p>
                    <Badge variant="secondary" className="mt-2">+$5 fee</Badge>
                  </CardContent>
                </Card>
              </div>

              {formData.vehicleType && (
                <div className="space-y-3">
                  <Label htmlFor="vehicleSubtype">
                    {formData.vehicleType === 'car' ? 'Car Brand' : 'Truck Brand'}
                  </Label>
                  <Select 
                    value={formData.vehicleSubtype} 
                    onValueChange={(value) => updateFormData({ vehicleSubtype: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={`Select your ${formData.vehicleType} brand`} />
                    </SelectTrigger>
                    <SelectContent>
                      {(formData.vehicleType === 'car' ? CAR_BRANDS : TRUCK_BRANDS).map((brand) => (
                        <SelectItem key={brand} value={brand}>
                          {brand}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  disabled={!formData.vehicleType || !formData.vehicleSubtype}
                >
                  Continue <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 4:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Choose Date & Time</CardTitle>
              <p className="text-muted-foreground">Select your preferred appointment date and time</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <TimeSlotPicker
                selectedDate={formData.scheduledDate as Date | undefined}
                selectedTime={formData.scheduledTime}
                packageType={formData.packageType || ""}
                onDateChange={(date) => updateFormData({ scheduledDate: date })}
                onTimeChange={(time) => updateFormData({ scheduledTime: time })}
                bookedSlots={[]} // You can add existing bookings here later
              />

              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  disabled={!formData.scheduledDate || !formData.scheduledTime}
                >
                  Continue <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 5:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Add Extras</CardTitle>
              <p className="text-muted-foreground">Enhance your service with additional options</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {EXTRAS.map((extra) => (
                  <Card 
                    key={extra.name} 
                    className={`p-4 cursor-pointer transition-all duration-200 hover:shadow-lg ${
                      formData.extras?.includes(extra.name) ? 'ring-2 ring-primary shadow-lg' : ''
                    }`}
                    onClick={() => {
                      const currentExtras = formData.extras || [];
                      if (currentExtras.includes(extra.name)) {
                        updateFormData({ extras: currentExtras.filter(e => e !== extra.name) });
                      } else {
                        updateFormData({ extras: [...currentExtras, extra.name] });
                      }
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id={extra.name}
                          checked={formData.extras?.includes(extra.name) || false}
                          onChange={() => {}} // Controlled by card click
                        />
                        <div>
                          <Label htmlFor={extra.name} className="font-medium cursor-pointer">
                            {extra.name}
                          </Label>
                          <p className="text-sm text-muted-foreground">{extra.description}</p>
                        </div>
                      </div>
                      <Badge className={extra.price === 0 ? "bg-green-100 text-green-700 hover:bg-green-100" : "bg-blue-100 text-blue-700 hover:bg-blue-100"}>
                        {extra.price === 0 ? "FREE" : `$${extra.price}`}
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-primary hover:bg-primary/90"
                >
                  Continue <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 6:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold flex items-center justify-center gap-2">
                <Sparkles className="w-8 h-8 text-secondary" />
                Contact Information
              </CardTitle>
              <p className="text-muted-foreground">Tell us how to reach you</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={formData.customerName}
                    onChange={(e) => updateFormData({ customerName: e.target.value })}
                    placeholder="Enter your full name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => updateFormData({ customerEmail: e.target.value })}
                    placeholder="Enter your email"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.customerPhone}
                    onChange={(e) => updateFormData({ customerPhone: e.target.value })}
                    placeholder="Enter your phone number"
                    className="mt-1"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  disabled={!formData.customerName || !formData.customerEmail || !formData.customerPhone}
                >
                  Get Quote <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 7:
        return (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Your Quote</CardTitle>
              <p className="text-muted-foreground">Review your service details and pricing</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Quote Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Package: {PACKAGES[formData.packageType!]?.name}</span>
                    <span>${PACKAGES[formData.packageType!]?.[formData.serviceType || 'dropoff']}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service Type: {formData.serviceType === 'mobile' ? 'Mobile Service' : 'Drop-off'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Vehicle: {formData.vehicleSubtype}</span>
                    {formData.vehicleType === 'truck' && <span>+$5</span>}
                  </div>
                  {formData.scheduledDate && formData.scheduledTime && (
                    <div className="flex justify-between">
                      <span>Scheduled: {new Date(formData.scheduledDate).toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        month: 'long', 
                        day: 'numeric',
                        year: 'numeric'
                      })} at {formData.scheduledTime}</span>
                    </div>
                  )}
                  {formData.extras && formData.extras.length > 0 && (
                    <div>
                      <span className="font-medium">Extras:</span>
                      {formData.extras.map((extraName) => {
                        const extra = EXTRAS.find(e => e.name === extraName);
                        return (
                          <div key={extraName} className="flex justify-between ml-4">
                            <span>• {extraName}</span>
                            <span>{extra?.price === 0 ? 'FREE' : `$${extra?.price}`}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>${calculateTotalPrice()}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" onClick={handleBack} className="flex-1">
                  <ArrowLeft className="mr-2 w-4 h-4" /> Back
                </Button>
                <Button 
                  onClick={handleNext} 
                  className="flex-1 bg-accent hover:bg-accent/90 text-white"
                  disabled={createQuoteMutation.isPending}
                >
                  {createQuoteMutation.isPending ? "Submitting..." : "Send Quote"}
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      case 8:
        return (
          <Card className="max-w-2xl mx-auto text-center">
            <CardContent className="p-12">
              <div className="text-6xl mb-6">✅</div>
              <h2 className="text-3xl font-bold mb-4">Quote Submitted Successfully!</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Thank you, {formData.customerName}! We've received your quote request for a total of ${calculateTotalPrice()}.
              </p>
              <p className="text-muted-foreground mb-6">
                Your quote has been submitted! Please allow for a 24-48 hour response. In some cases, we may respond sooner.
              </p>
              <p className="text-sm text-muted-foreground mb-8">
                Redirecting to homepage in a few seconds...
              </p>
              <Button 
                onClick={() => setLocation('/')}
                className="bg-primary hover:bg-primary/90"
              >
                Go to Homepage Now
              </Button>
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 text-center">
          <div className="flex justify-center items-center gap-2 mb-4">
            {[1, 2, 3, 4, 5, 6, 7].map((num) => (
              <div key={num} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= num ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  {num}
                </div>
                {num < 7 && <div className={`w-8 h-0.5 ${step > num ? 'bg-primary' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
          <h1 className="text-2xl font-bold text-primary">
            Step {step} of 7: {
              step === 1 ? 'Choose Package' :
              step === 2 ? 'Service Location' :
              step === 3 ? 'Vehicle Details' :
              step === 4 ? 'Date & Time' :
              step === 5 ? 'Add Extras' :
              step === 6 ? 'Contact Info' :
              'Review Quote'
            }
          </h1>
        </div>

        {renderStep()}
      </div>
    </div>
  );
}