                              import { useState } from "react";
                              import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
                              import { Navigation } from "@/components/navigation";
                              import {
                                Card,
                                CardContent,
                                CardHeader,
                                CardTitle
                              } from "@/components/ui/card";
                              import { Button } from "@/components/ui/button";
                              import { Badge } from "@/components/ui/badge";
                              import { Input } from "@/components/ui/input";
                              import { Label } from "@/components/ui/label";
                              import { Textarea } from "@/components/ui/textarea";
                              import {
                                Select,
                                SelectContent,
                                SelectItem,
                                SelectTrigger,
                                SelectValue
                              } from "@/components/ui/select";
                              import {
                                Dialog,
                                DialogContent,
                                DialogHeader,
                                DialogTitle,
                                DialogTrigger
                              } from "@/components/ui/dialog";
                              import {
                                Tabs,
                                TabsContent,
                                TabsList,
                                TabsTrigger
                              } from "@/components/ui/tabs";
                              import {
                                Calendar,
                                DollarSign,
                                Clock,
                                Users,
                                LogOut,
                                TriangleAlert,
                                Plus,
                                CheckCircle,
                                XCircle,
                                Mail
                              } from "lucide-react";
                              import { useToast } from "@/hooks/use-toast";
                              import { useLocation } from "wouter";
                              import { apiRequest } from "@/lib/queryClient";
                              import type { Job, Staff, Quote } from "@shared/schema";

                              export default function AdminDashboard() {
                                const [, setLocation] = useLocation();
                                const { toast } = useToast();
                                const queryClient = useQueryClient();

                                const { data: jobs = [], isLoading: jobsLoading } = useQuery<Job[]>({
                                  queryKey: ["/api/jobs"],
                                });

                                const { data: staff = [], isLoading: staffLoading } = useQuery<Staff[]>({
                                  queryKey: ["/api/staff"],
                                });

                                const { data: quotes = [], isLoading: quotesLoading } = useQuery<Quote[]>({
                                  queryKey: ["/api/quotes"],
                                });

                                const updateJobMutation = useMutation({
                                  mutationFn: async ({ id, updates }: { id: number; updates: Partial<Job> }) => {
                                    const response = await fetch(`/api/jobs/${id}`, {
                                      method: "PATCH",
                                      headers: { "Content-Type": "application/json" },
                                      body: JSON.stringify(updates),
                                      credentials: "include",
                                    });
                                    if (!response.ok) throw new Error("Failed to update job");
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
                                    toast({
                                      title: "Job Updated",
                                      description: "Job assignment updated successfully!",
                                    });
                                  },
                                });

                                const approveQuoteMutation = useMutation({
                                  mutationFn: async ({ quoteId, scheduledDate }: { quoteId: number; scheduledDate: string }) => {
                                    const response = await apiRequest('POST', `/api/quotes/${quoteId}/approve`, { scheduledDate });
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
                                    queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
                                    toast({
                                      title: "Quote Approved",
                                      description: "Quote approved and job scheduled successfully!",
                                    });
                                  },
                                });

                                const denyQuoteMutation = useMutation({
                                  mutationFn: async ({ quoteId, reason }: { quoteId: number; reason: string }) => {
                                    const response = await apiRequest('POST', `/api/quotes/${quoteId}/deny`, { reason });
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
                                    toast({
                                      title: "Quote Denied",
                                      description: "Quote denied and customer notified.",
                                    });
                                  },
                                });

                                const handleLogout = () => {
                                  setLocation("/admin");
                                };
                                const handleAssignJob = (jobId: number, staffName: string) => {
                                  updateJobMutation.mutate({
                                    id: jobId,
                                    updates: { assignedStaff: staffName }
                                  });
                                };

                                const pendingQuotes = quotes.filter(quote => quote.status === 'pending');
                                const completedJobs = jobs.filter(job => job.status === 'completed');
                                const totalRevenue = completedJobs.reduce((sum, job) => sum + (job.totalPrice || job.total_price), 0);
                                const activeStaff = staff.filter(s => s.isActive);

                                const getStatusColor = (status: string) => {
                                  switch (status) {
                                    case "completed": return "bg-green-100 text-green-700";
                                    case "in-progress": return "bg-blue-100 text-blue-700";
                                    case "scheduled": return "bg-orange-100 text-orange-700";
                                    default: return "bg-gray-100 text-gray-700";
                                  }
                                };

                                const [denyReason, setDenyReason] = useState("");
                                const [selectedQuote, setSelectedQuote] = useState<any>(null);
                                const [newStaffForm, setNewStaffForm] = useState({
                                  name: "",
                                  email: "",
                                  hourlyRate: "",
                                  notes: ""
                                });

                                const createStaffMutation = useMutation({
                                  mutationFn: async (staffData: any) => {
                                    const response = await fetch('/api/staff', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify(staffData),
                                      credentials: 'include',
                                    });

                                    if (!response.ok) throw new Error('Failed to create staff');
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
                                    setNewStaffForm({ name: "", email: "", hourlyRate: "", notes: "" });
                                    toast({
                                      title: "Staff Added",
                                      description: "New staff member has been added successfully.",
                                    });
                                  },
                                });

                                const updateStaffMutation = useMutation({
                                  mutationFn: async ({ id, updates }: { id: number; updates: Partial<Staff> }) => {
                                    const response = await fetch(`/api/staff/${id}`, {
                                      method: 'PATCH',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify(updates),
                                      credentials: 'include',
                                    });
                                    if (!response.ok) throw new Error('Failed to update staff');
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
                                    toast({
                                      title: "Staff Updated",
                                      description: "Staff member updated successfully.",
                                    });
                                  },
                                });

                                const deleteStaffMutation = useMutation({
                                  mutationFn: async (id: number) => {
                                    const response = await fetch(`/api/staff/${id}`, {
                                      method: 'DELETE',
                                      credentials: 'include',
                                    });
                                    if (!response.ok) throw new Error('Failed to delete staff');
                                    return response.json();
                                  },
                                  onSuccess: () => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
                                    toast({
                                      title: "Staff Deleted",
                                      description: "Staff member deleted successfully.",
                                    });
                                  },
                                });

                                const notifyStaffMutation = useMutation({
                                  mutationFn: async () => {
                                    const response = await fetch('/api/staff/notify-available-jobs', {
                                      method: 'POST',
                                      credentials: 'include',
                                    });
                                    if (!response.ok) throw new Error('Failed to notify staff');
                                    return response.json();
                                  },
                                  onSuccess: (data) => {
                                    toast({
                                      title: "Staff Notified",
                                      description: data.message,
                                    });
                                  },
                                });
                                if (jobsLoading || staffLoading || quotesLoading) {
                                  return (
                                    <div className="min-h-screen bg-neutral-50">
                                      <Navigation />
                                      <div className="flex items-center justify-center py-20">
                                        <div className="text-center">Loading dashboard...</div>
                                      </div>
                                    </div>
                                  );
                                }

                                return (
                                  <div className="min-h-screen bg-neutral-50">
                                    {/* Admin Navigation */}
                                    <nav className="bg-white shadow-lg">
                                      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                                        <div className="flex justify-between items-center h-16">
                                          <div className="flex items-center">
                                            <h1 className="text-xl font-bold text-primary flex items-center">
                                              <Calendar className="mr-2" />
                                              Admin Dashboard
                                            </h1>
                                          </div>
                                          <div className="flex items-center space-x-4">
                                            <span className="text-muted-foreground">Welcome, Carson</span>
                                            <Button  
                                              variant="ghost"  
                                              onClick={handleLogout}
                                              className="text-accent hover:text-accent/80"
                                            >
                                              <LogOut className="mr-1 w-4 h-4" />
                                              Logout
                                            </Button>
                                          </div>
                                        </div>
                                      </div>
                                    </nav>

                                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                                      {/* Dashboard Header */}
                                      <div className="mb-8">
                                        <h2 className="text-3xl font-bold text-foreground mb-2">Daily Overview</h2>
                                        <p className="text-muted-foreground">Manage your car detailing business efficiently</p>
                                      </div>

                                      {/* Stats Cards */}
                                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                                        <Card>
                                          <CardContent className="p-6">
                                            <div className="flex items-center justify-between">
                                              <div>
                                                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                                                  Completed Jobs
                                                </p>
                                                <p className="text-3xl font-bold text-primary">{completedJobs.length}</p>
                                              </div>
                                              <div className="bg-primary/10 rounded-full p-3">
                                                <Calendar className="text-primary w-6 h-6" />
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>

                                        <Card>
                                          <CardContent className="p-6">
                                            <div className="flex items-center justify-between">
                                              <div>
                                                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                                                  Revenue (Completed)
                                                </p>
                                                <p className="text-3xl font-bold text-green-600">${totalRevenue}</p>
                                              </div>
                                              <div className="bg-green-100 rounded-full p-3">
                                                <DollarSign className="text-green-600 w-6 h-6" />
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>

                                        <Card>
                                          <CardContent className="p-6">
                                            <div className="flex items-center justify-between">
                                              <div>
                                                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                                                  Pending Quotes
                                                </p>
                                                <p className="text-3xl font-bold text-secondary">{pendingQuotes.length}</p>
                                              </div>
                                              <div className="bg-orange-100 rounded-full p-3">
                                                <Clock className="text-secondary w-6 h-6" />
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>

                                        <Card>
                                          <CardContent className="p-6">
                                            <div className="flex items-center justify-between">
                                              <div>
                                                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                                                  Staff On Duty
                                                </p>
                                                <p className="text-3xl font-bold text-primary">{activeStaff.length}</p>
                                              </div>
                                              <div className="bg-primary/10 rounded-full p-3">
                                                <Users className="text-primary w-6 h-6" />
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>
                                      </div>
                                      {/* Tabs for different sections */}
                                      <Tabs defaultValue="quotes" className="w-full">
                                        <TabsList className="grid w-full grid-cols-3">
                                          <TabsTrigger value="quotes">Quote Requests ({pendingQuotes.length})</TabsTrigger>
                                          <TabsTrigger value="jobs">Job Schedule ({jobs.length})</TabsTrigger>
                                          <TabsTrigger value="staff">Staff Management</TabsTrigger>
                                        </TabsList>

                                        <TabsContent value="quotes" className="space-y-6">
                                          <Card>
                                            <CardHeader>
                                              <CardTitle className="flex items-center">
                                                <Mail className="mr-2 w-5 h-5" />
                                                Quote Requests ({quotes.filter(q => q.status === 'pending').length} pending)
                                              </CardTitle>
                                            </CardHeader>
                                            <CardContent>
                                              {quotes.filter(q => q.status === 'pending').length === 0 ? (
                                                <p className="text-muted-foreground text-center py-8">No pending quote requests</p>
                                              ) : (
                                                <div className="space-y-4">
                                                  {quotes.filter(q => q.status === 'pending').map((quote) => (
                                                    <Card key={quote.id} className="border-l-4 border-orange-400">
                                                      <CardContent className="space-y-4">
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                          <div className="space-y-3">
                                                            <div>
                                                              <p className="text-sm font-medium text-gray-600">Customer</p>
                                                              <p className="text-lg font-semibold">{quote.customerName || quote.customer_name}</p>
                                                              <p className="text-sm text-muted-foreground">{quote.customerEmail || quote.customer_email}</p>
                                                              <p className="text-sm text-muted-foreground">{quote.customerPhone || quote.customer_phone}</p>
                                                            </div>
                                                            <div>
                                                              <p className="text-sm font-medium text-gray-600">Vehicle Information</p>
                                                              <p className="text-sm font-semibold">
                                                                {quote.vehicleSubtype || quote.vehicle_subtype} ({quote.vehicleType || quote.vehicle_type})
                                                              </p>
                                                            </div>
                                                            <div>
                                                              <p className="text-sm font-medium text-gray-600">Service Package</p>
                                                              <p className="text-sm font-semibold">{quote.packageType || quote.package_type}</p>
                                                              <p className="text-sm text-muted-foreground">
                                                                {(quote.serviceType || quote.service_type) === 'mobile' ? '🚗 Mobile Service' : '🏪 Drop-off Service'}
                                                              </p>
                                                            </div>
                                                          </div>

                                                          <div className="space-y-3">
                                                            <div>
                                                              <p className="text-sm font-medium text-gray-600">Customer's Requested Time</p>
                                                              {(quote.scheduledDate || quote.scheduled_date) && (quote.scheduledTime || quote.scheduled_time) ? (
                                                                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                                                                  <p className="text-lg font-semibold text-blue-800">
                                                                    📅 {new Date(quote.scheduledDate || quote.scheduled_date).toLocaleDateString('en-US', {
                                                                      weekday: 'long',
                                                                      year: 'numeric',
                                                                      month: 'long',
                                                                      day: 'numeric'
                                                                    })}
                                                                  </p>
                                                                  <p className="text-lg font-semibold text-blue-800">
                                                                    🕐 {quote.scheduledTime || quote.scheduled_time}
                                                                  </p>
                                                                </div>
                                                              ) : (
                                                                <p className="text-sm text-orange-600 bg-orange-50 p-2 rounded">
                                                                  ⚠ No specific time requested
                                                                </p>
                                                              )}
                                                            </div>
                                                            <div>
                                                              <p className="text-sm font-medium text-gray-600">Detailed Pricing Breakdown</p>
                                                              <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                                                                <div className="flex justify-between items-center">
                                                                  <span className="text-sm">
                                                                    {quote.packageType || quote.package_type} Package
                                                                    ({(quote.serviceType || quote.service_type) === 'mobile' ? 'Mobile' : 'Drop-off'}):
                                                                  </span>
                                                                  <span className="font-semibold">${quote.basePrice || quote.base_price}</span>
                                                                </div>
                                                                {(quote.vehicleType || quote.vehicle_type) === 'truck' &&
                                                                  (quote.truckFee || quote.truck_fee) > 0 && (
                                                                    <div className="flex justify-between items-center">
                                                                      <span className="text-sm">Truck Fee:</span>
                                                                      <span className="font-semibold">+${quote.truckFee || quote.truck_fee}</span>
                                                                    </div>
                                                                  )}
                                                                {quote.extras && quote.extras.length > 0 && (
                                                                  <div className="flex justify-between items-center">
                                                                    <span className="text-sm">Extras ({quote.extras.length} items):</span>
                                                                    <span className="font-semibold">Included</span>
                                                                  </div>
                                                                )}
                                                                <div className="border-t pt-2 mt-2">
                                                                  <div className="flex justify-between items-center">
                                                                    <span className="font-bold">Total Amount:</span>
                                                                    <span className="text-2xl font-bold text-green-700">
                                                                      ${quote.totalPrice || quote.total_price}
                                                                    </span>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                            </div>
                                                            </div>

                                                            {quote.extras && quote.extras.length > 0 && (
                                                            <div className="mb-4">
                                                            <p className="text-sm font-medium mb-2">Extras:</p>
                                                            <div className="flex flex-wrap gap-2">
                                                              {quote.extras.map((extra, index) => (
                                                                <Badge key={index} variant="secondary" className="text-xs">
                                                                  {extra}
                                                                </Badge>
                                                              ))}
                                                            </div>
                                                            </div>
                                                            )}

                                                            <div className="flex gap-3">
                                                            <Button
                                                            className="bg-green-600 hover:bg-green-700 text-white"
                                                            onClick={() => {
                                                              const scheduledDateTime = quote.scheduledDate && quote.scheduledTime
                                                                ? new Date(quote.scheduledDate).toISOString()
                                                                : new Date().toISOString();
                                                              approveQuoteMutation.mutate({ quoteId: quote.id, scheduledDate: scheduledDateTime });
                                                            }}
                                                            >
                                                            <CheckCircle className="mr-2 w-4 h-4" />
                                                            Approve
                                                            </Button>

                                                            <Dialog>
                                                            <DialogTrigger asChild>
                                                              <Button variant="destructive">
                                                                <XCircle className="mr-2 w-4 h-4" />
                                                                Deny Quote
                                                              </Button>
                                                            </DialogTrigger>
                                                            <DialogContent>
                                                              <DialogHeader>
                                                                <DialogTitle>Deny Quote Request</DialogTitle>
                                                              </DialogHeader>
                                                              <div className="space-y-4">
                                                                <div>
                                                                  <Label htmlFor="denyReason">Reason for denial</Label>
                                                                  <Textarea
                                                                    id="denyReason"
                                                                    placeholder="Please provide a reason for denying this quote..."
                                                                    className="mt-1"
                                                                    onChange={(e) => {
                                                                      const denyButton = e.target
                                                                        .closest('.space-y-4')
                                                                        ?.querySelector('button[data-deny]') as HTMLButtonElement;
                                                                      if (denyButton) {
                                                                        denyButton.dataset.reason = e.target.value;
                                                                      }
                                                                    }}
                                                                  />
                                                                </div>
                                                                <Button
                                                                  data-deny
                                                                  variant="destructive"
                                                                  className="w-full"
                                                                  onClick={(e) => {
                                                                    const button = e.target as HTMLButtonElement;
                                                                    const reason = button.dataset.reason;
                                                                    if (reason) {
                                                                      denyQuoteMutation.mutate({ quoteId: quote.id, reason });
                                                                    }
                                                                  }}
                                                                >
                                                                  Confirm Denial
                                                                </Button>
                                                              </div>
                                                            </DialogContent>
                                                            </Dialog>
                                                            </div>
                                                            </CardContent>
                                                            </Card>
                                                            ))}
                                                            </div>
                                                            )}
                                                            </CardContent>
                                                            </Card>
                                                            </TabsContent>
                                        <TabsContent value="staff" className="space-y-6">
                                          <Card>
                                            <CardHeader>
                                              <div className="flex items-center justify-between">
                                                <CardTitle className="flex items-center">
                                                  <Users className="mr-2 w-5 h-5" />
                                                  Staff Management ({activeStaff.length} active)
                                                </CardTitle>
                                                <div className="flex gap-2">
                                                  <Button
                                                    onClick={() => notifyStaffMutation.mutate()}
                                                    className="bg-blue-600 hover:bg-blue-700"
                                                    disabled={notifyStaffMutation.isPending}
                                                  >
                                                    <Mail className="mr-2 w-4 h-4" />
                                                    {notifyStaffMutation.isPending ? "Notifying..." : "Notify Available Jobs"}
                                                  </Button>
                                                  <Dialog>
                                                    <DialogTrigger asChild>
                                                      <Button className="bg-primary hover:bg-primary/90">
                                                        <Plus className="mr-2 w-4 h-4" />
                                                        Add Staff Member
                                                      </Button>
                                                    </DialogTrigger>
                                                    <DialogContent>
                                                      <DialogHeader>
                                                        <DialogTitle>Add New Staff Member</DialogTitle>
                                                      </DialogHeader>
                                                      <div className="space-y-4">
                                                        <div>
                                                          <Label htmlFor="staffName">Name</Label>
                                                          <Input
                                                            id="staffName"
                                                            value={newStaffForm.name}
                                                            onChange={(e) => setNewStaffForm({ ...newStaffForm, name: e.target.value })}
                                                            placeholder="Enter staff member name"
                                                            className="mt-1"
                                                          />
                                                        </div>
                                                        <div>
                                                          <Label htmlFor="staffEmail">Email</Label>
                                                          <Input
                                                            id="staffEmail"
                                                            type="email"
                                                            value={newStaffForm.email || ""}
                                                            onChange={(e) => setNewStaffForm({ ...newStaffForm, email: e.target.value })}
                                                            placeholder="Enter staff member email"
                                                            className="mt-1"
                                                          />
                                                        </div>
                                                        <div>
                                                          <Label htmlFor="hourlyRate">Hourly Rate ($)</Label>
                                                          <Input
                                                            id="hourlyRate"
                                                            type="number"
                                                            value={newStaffForm.hourlyRate}
                                                            onChange={(e) => setNewStaffForm({ ...newStaffForm, hourlyRate: e.target.value })}
                                                            placeholder="15.00"
                                                            className="mt-1"
                                                          />
                                                        </div>
                                                        <div>
                                                          <Label htmlFor="staffNotes">Notes</Label>
                                                          <Textarea
                                                            id="staffNotes"
                                                            value={newStaffForm.notes}
                                                            onChange={(e) => setNewStaffForm({ ...newStaffForm, notes: e.target.value })}
                                                            placeholder="Any special notes (e.g., doesn't do trucks, only weekends, etc.)"
                                                            className="mt-1"
                                                          />
                                                        </div>
                                                        <Button
                                                          className="w-full bg-primary hover:bg-primary/90"
                                                          onClick={() => {
                                                            if (newStaffForm.name && newStaffForm.hourlyRate) {
                                                              createStaffMutation.mutate({
                                                                name: newStaffForm.name,
                                                                email: newStaffForm.email,
                                                                hourlyRate: Math.round(parseFloat(newStaffForm.hourlyRate) * 100),
                                                                notes: newStaffForm.notes
                                                              });
                                                            }
                                                          }}
                                                          disabled={!newStaffForm.name || !newStaffForm.hourlyRate || createStaffMutation.isPending}
                                                        >
                                                          {createStaffMutation.isPending ? "Adding..." : "Add Staff Member"}
                                                        </Button>
                                                      </div>
                                                    </DialogContent>
                                                  </Dialog>
                                                </div>
                                              </div>
                                            </CardHeader>
                                            <CardContent>
                                              <div className="space-y-4">
                                                {staff.length === 0 ? (
                                                  <div className="text-center py-8">
                                                    <Users className="mx-auto w-6 h-6 text-muted-foreground mb-2" />
                                                    <p className="text-muted-foreground">No staff members found.</p>
                                                  </div>
                                                ) : (
                                                  staff.map((s) => (
                                                    <Card key={s.id}>
                                                      <CardContent className="flex justify-between items-center">
                                                        <div>
                                                          <p className="font-semibold">{s.name}</p>
                                                          <p className="text-sm text-muted-foreground">{s.email}</p>
                                                        </div>
                                                        <div className="flex gap-2">
                                                          <Button
                                                            variant="outline"
                                                            size="sm"
                                                            onClick={() =>
{staff.map((s) => (
                                                              <CardContent>
                                                                <div className="space-y-4">
                                                                  {staff.length === 0 ? (
                                                                    <div className="text-center py-8">
                                                                      <Users className="mx-auto w-6 h-6 text-muted-foreground mb-2" />
                                                                      <p className="text-muted-foreground">No staff members found.</p>
                                                                    </div>
                                                                  ) : (
                                                                    staff.map((s) => (
                                                                      <Card key={s.id}>
                                                                        <CardContent className="flex justify-between items-center">
                                                                          <div>
                                                                            <p className="font-semibold">{s.name}</p>
                                                                            <p className="text-sm text-muted-foreground">{s.email}</p>
                                                                          </div>
                                                                          <div className="flex gap-2">
                                                                            <Button
                                                                              variant="outline"
                                                                              size="sm"
                                                                              onClick={() =>
                                                                                updateStaffMutation.mutate({
                                                                                  id: s.id,
                                                                                  updates: { isActive: !s.isActive },
                                                                                })
                                                                              }
                                                                            >
                                                                              {s.isActive ? "Deactivate" : "Activate"}
                                                                            </Button>
                                                                            <Button
                                                                              variant="destructive"
                                                                              size="sm"
                                                                              onClick={() => deleteStaffMutation.mutate(s.id)}
                                                                            >
                                                                              Delete
                                                                            </Button>
                                                                          </div>
                                                                        </CardContent>
                                                                      </Card>
                                                                    ))
                                                                  )}
                                                                </div>
                                                              </CardContent>
