import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Droplet, Star, Armchair, Car } from "lucide-react";
import { PackageData } from "@/lib/types";

interface ServiceCardProps {
  packageKey: string;
  packageData: PackageData;
  serviceType: 'dropoff' | 'mobile';
  isSelected: boolean;
  onSelect: () => void;
}

const iconMap = {
  droplet: Droplet,
  star: Star,
  armchair: Armchair,
  car: Car
};

export function ServiceCard({ 
  packageKey, 
  packageData, 
  serviceType, 
  isSelected, 
  onSelect 
}: ServiceCardProps) {
  const Icon = iconMap[packageData.icon as keyof typeof iconMap] || Car;
  const price = packageData[serviceType];
  const serviceLabel = serviceType === 'mobile' ? 'Mobile' : 'Drop-off';
  const isPopular = packageKey === 'full';

  return (
    <Card 
      className={`service-card cursor-pointer hover:shadow-xl transition-all duration-200 relative ${
        isSelected ? 'selected' : ''
      } ${isSelected && isPopular ? 'ring-2 ring-secondary' : ''} ${
        isSelected && !isPopular ? 'ring-2 ring-primary' : ''
      }`}
      onClick={onSelect}
    >
      {isPopular && (
        <Badge className="absolute top-0 right-0 bg-accent text-white rounded-bl-lg rounded-tr-lg">
          POPULAR
        </Badge>
      )}
      
      <CardContent className="p-6">
        <div className="text-center mb-4">
          <Icon className={`w-10 h-10 mx-auto mb-3 ${
            isPopular ? 'text-secondary' : 'text-primary'
          }`} />
          <h3 className="text-xl font-bold text-foreground">{packageData.name}</h3>
        </div>
        
        <div className="text-center mb-4">
          <div className="price-display">
            <span className={`text-3xl font-bold ${
              isPopular ? 'text-secondary' : 'text-primary'
            }`}>
              ${price}
            </span>
            <span className="text-sm text-muted-foreground block">{serviceLabel}</span>
          </div>
        </div>
        
        <ul className="space-y-2 text-sm text-muted-foreground mb-6">
          {packageData.description.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
              {feature}
            </li>
          ))}
        </ul>
        
        <Button 
          className={`w-full ${
            isPopular 
              ? 'bg-secondary hover:bg-secondary/90' 
              : 'bg-primary hover:bg-primary/90'
          }`}
        >
          Select Package
        </Button>
      </CardContent>
    </Card>
  );
}
