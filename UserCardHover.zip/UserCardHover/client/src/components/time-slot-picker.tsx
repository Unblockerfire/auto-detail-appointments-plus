
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { CalendarDays, Clock } from "lucide-react";

interface TimeSlotPickerProps {
  selectedDate: Date | undefined;
  selectedTime: string | undefined;
  packageType: string;
  onDateChange: (date: Date | undefined) => void;
  onTimeChange: (time: string) => void;
  bookedSlots: Array<{ date: string; time: string }>;
}

export function TimeSlotPicker({
  selectedDate,
  selectedTime,
  packageType,
  onDateChange,
  onTimeChange,
  bookedSlots
}: TimeSlotPickerProps) {
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);

  // Define time slots based on seasons and day type
  const getTimeSlots = (date: Date) => {
    const month = date.getMonth() + 1; // JavaScript months are 0-indexed
    const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    
    // June 2nd - August 19th (Summer)
    const isSummer = (month === 6 && date.getDate() >= 2) || 
                     month === 7 || 
                     (month === 8 && date.getDate() <= 19);
    
    // September - June (School Year)
    const isSchoolYear = (month >= 9 && month <= 12) || (month >= 1 && month <= 6);

    if (isSummer) {
      if (isWeekend) {
        // Summer weekends: 8am, 10am, 2pm, 4pm, 6pm, 7:30pm
        const slots = ["8:00 AM", "10:00 AM", "2:00 PM", "4:00 PM", "6:00 PM"];
        // Only add 7:30 PM for express cleans
        if (packageType === "express") {
          slots.push("7:30 PM");
        }
        return slots;
      } else {
        // Summer weekdays: 10am, 2pm, 4:30pm, 6:30pm
        return ["10:00 AM", "2:00 PM", "4:30 PM", "6:30 PM"];
      }
    } else if (isSchoolYear) {
      if (isWeekend) {
        // School year weekends: 10am, 2:30pm, 4:30pm, 6:30pm
        return ["10:00 AM", "2:30 PM", "4:30 PM", "6:30 PM"];
      } else {
        // School year weekdays: 4:30pm, 6pm
        return ["4:30 PM", "6:00 PM"];
      }
    }
    
    return [];
  };

  // Filter out already booked slots
  const getAvailableSlots = (date: Date) => {
    const allSlots = getTimeSlots(date);
    const dateString = date.toDateString();
    
    return allSlots.filter(slot => {
      return !bookedSlots.some(booked => 
        booked.date === dateString && booked.time === slot
      );
    });
  };

  useEffect(() => {
    if (selectedDate) {
      setAvailableSlots(getAvailableSlots(selectedDate));
    }
  }, [selectedDate, bookedSlots, packageType]);

  // Disable dates that are in the past
  const disabledDays = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CalendarDays className="mr-2 w-5 h-5" />
            Select Date
          </CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={onDateChange}
            disabled={disabledDays}
            className="rounded-md border w-fit"
          />
        </CardContent>
      </Card>

      {selectedDate && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="mr-2 w-5 h-5" />
              Available Time Slots
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {selectedDate.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </CardHeader>
          <CardContent>
            {availableSlots.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No available time slots for this date. Please select another date.
              </p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {availableSlots.map((slot) => (
                  <Button
                    key={slot}
                    variant={selectedTime === slot ? "default" : "outline"}
                    onClick={() => onTimeChange(slot)}
                    className="h-12 text-sm"
                  >
                    {slot}
                  </Button>
                ))}
              </div>
            )}
            
            {packageType !== "express" && selectedDate && (
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> 7:30 PM slots are only available for Express Wash packages.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {selectedDate && selectedTime && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-green-800">Selected Appointment</p>
                <p className="text-sm text-green-700">
                  {selectedDate.toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    month: 'long', 
                    day: 'numeric',
                    year: 'numeric'
                  })} at {selectedTime}
                </p>
              </div>
              <Badge className="bg-green-600 text-white">
                Confirmed
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
