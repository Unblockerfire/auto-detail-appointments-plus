import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { PACKAGES } from "@/lib/types";

interface QuoteSummaryProps {
  packageType: string;
  serviceType: 'dropoff' | 'mobile';
  mobileDiscount: boolean;
  airFreshener: boolean;
  onBookService: () => void;
}

export function QuoteSummary({
  packageType,
  serviceType,
  mobileDiscount,
  airFreshener,
  onBookService
}: QuoteSummaryProps) {
  if (!packageType) return null;

  const packageData = PACKAGES[packageType];
  const basePrice = packageData[serviceType];
  let totalPrice = basePrice;

  // Apply mobile discount if applicable
  if (serviceType === 'mobile' && mobileDiscount) {
    totalPrice -= 10;
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Quote Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center py-2">
            <span className="font-medium">Selected Package:</span>
            <span className="font-bold">{packageData.name}</span>
          </div>
          
          <div className="flex justify-between items-center py-2">
            <span className="font-medium">Service Type:</span>
            <span className="font-bold">
              {serviceType === 'mobile' ? 'Mobile Service' : 'Drop-off Service'}
            </span>
          </div>
          
          <div className="flex justify-between items-center py-2">
            <span className="font-medium">Base Price:</span>
            <span className="font-bold">${basePrice}</span>
          </div>
          
          {serviceType === 'mobile' && (
            <div className="flex justify-between items-center py-2">
              <span className="font-medium">Mobile Service Fee:</span>
              <span className="font-bold text-secondary">+$10</span>
            </div>
          )}
          
          {serviceType === 'mobile' && mobileDiscount && (
            <div className="flex justify-between items-center py-2">
              <span className="font-medium">Mobile Discount:</span>
              <span className="font-bold text-green-600">-$10</span>
            </div>
          )}
          
          {airFreshener && (
            <div className="flex justify-between items-center py-2">
              <span className="font-medium">Little Tree Air Freshener:</span>
              <span className="font-bold text-green-600">FREE</span>
            </div>
          )}
          
          <Separator className="my-4" />
          
          <div className="flex justify-between items-center py-4 text-xl font-bold">
            <span>Total:</span>
            <span className="text-primary">${totalPrice}</span>
          </div>
        </div>
        
        <div className="mt-6 text-center">
          <Button 
            onClick={onBookService}
            className="bg-accent hover:bg-accent/90 text-white px-8 py-3 text-lg font-bold"
          >
            Book This Service
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
