export interface PackageData {
  name: string;
  emoji: string;
  dropoff: number;
  mobile: number;
  description: string[];
  features: string[];
  popular?: boolean;
}

export interface QuoteFormData {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  packageType: string;
  serviceType: 'dropoff' | 'mobile';
  vehicleType: 'car' | 'truck';
  vehicleSubtype: string;
  mobileDiscount: boolean;
  extras: string[];
  basePrice: number;
  truckFee: number;
  totalPrice: number;
  scheduledDate?: Date | string;
  scheduledTime?: string;
}

export interface AdminUser {
  email: string;
  name: string;
}

export const PACKAGES: Record<string, PackageData> = {
  express: {
    name: 'Express Wash',
    emoji: '🧼',
    dropoff: 30,
    mobile: 40,
    description: ['A quick maintenance wash for regular upkeep'],
    features: [
      'Regular soap wash',
      'Hand wash & rinse',
      'Wheels scrubbed',
      'Windows wiped',
      'Light vacuum'
    ]
  },
  full: {
    name: 'Full Detail (Interior + Exterior)',
    emoji: '💦',
    dropoff: 120,
    mobile: 140,
    description: ['Best for full cleaning and protection inside and out'],
    features: [
      'Foam cannon wash & hand dry',
      'Wax applied',
      'Deep vacuum + shampoo seats/floors',
      'Dashboard, panels cleaned + protected',
      'Tires, windows, mirrors polished'
    ],
    popular: true
  },
  interior: {
    name: 'Interior Only',
    emoji: '🧽',
    dropoff: 70,
    mobile: 85,
    description: ['For a deep clean inside only'],
    features: [
      'Full vacuum',
      'Stain removal',
      'Steam clean + plastics conditioning'
    ]
  },
  exterior: {
    name: 'Exterior Only',
    emoji: '✨',
    dropoff: 65,
    mobile: 80,
    description: ['For a spotless exterior shine'],
    features: [
      'Foam wash',
      'Hand-dry, wax or ceramic seal',
      'Tire shine + trim protect'
    ]
  }
};

export const CAR_BRANDS = [
  'Toyota',
  'Honda',
  'Ford',
  'Chevrolet',
  'Nissan',
  'BMW',
  'Mercedes-Benz',
  'Audi',
  'Lexus',
  'Hyundai',
  'Kia',
  'Mazda',
  'Subaru',
  'Volkswagen',
  'Acura',
  'Infiniti',
  'Cadillac',
  'Lincoln',
  'Jeep',
  'Dodge',
  'Ram',
  'Tesla'
];

export const TRUCK_BRANDS = [
  'Ford F-150',
  'Chevrolet Silverado',
  'Ram 1500',
  'GMC Sierra',
  'Toyota Tundra',
  'Nissan Titan',
  'Ford F-250/F-350',
  'Chevrolet Colorado',
  'Toyota Tacoma',
  'Nissan Frontier',
  'Honda Ridgeline',
  'Ford Ranger'
];

export const EXTRAS = [
  { name: "Little Tree Black Ice Air Freshener", description: "Premium air freshener for lasting freshness", price: 0 },
  { name: "Tire Shine", description: "Long-lasting tire shine treatment", price: 10 },
  { name: "Dashboard Protection", description: "UV protection treatment for dashboard", price: 15 }
];